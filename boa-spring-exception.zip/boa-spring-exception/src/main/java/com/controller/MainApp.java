package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.EmployeeDAO;
import com.model.Employee;
import com.model.Employees;

@RestController
@RequestMapping("/mainapp")
public class MainApp {
	
	@Autowired
	EmployeeDAO dao;
	
	@GetMapping(path = "/empshow", produces = "application/json")
	public Employees showAll(
			@RequestHeader(name = "X-COM-PERSIST", required = true) String persist,
			@RequestHeader(name = "X-COM-LOCATION", defaultValue = "ASIA") String country
			) {
		return dao.getAll();
	}
	
	/**
	 * @param emp
	 * @return
	 * @throws Exception 
	 */
	@PostMapping("/addemp")
	public ResponseEntity<Object> addEmp(@RequestBody Employee emp) throws Exception {
		Integer id = dao.getAll().getEmployeeList().size()+1;
		emp.setId(id);
		
		dao.addEmployee(emp);
		return ResponseEntity.ok("OK");
	}

}
