package com.example.boaconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
