package com.dao;

import org.springframework.stereotype.Repository;

import com.model.Employee;
import com.model.Employees;

@Repository
public class EmployeeDAO {
	
	private static Employees list= new Employees();
	
	static {
		list.getEmployeeList().add(new Employee(1, "admin", "admin@mail.com", "mumbai"));
		list.getEmployeeList().add(new Employee(2, "john", "john@mail.com", "newyork"));
		list.getEmployeeList().add(new Employee(1, "david", "david@mail.com", "Australia"));
	}
	
	public Employees getAll() {
		return list;
	}

	public void addEmployee(Employee employee) {
		list.getEmployeeList().add(employee);
	}
	
	public Employee findEmployee(String name) {
		
		for(Employee em: list.getEmployeeList()) {
			
			if(em.getFirstName().equals(name)) {
				return em;
			}
			
		}
		return null;
		
	}
}
