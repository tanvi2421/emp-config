package com.dao;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.Employee;
@Repository
public interface EmployeeDao extends PagingAndSortingRepository<Employee, Integer> {

	@Transactional
	@Modifying
	@Query("update Employee set email=:email where empName=:empName")
	Integer updateEmail(String email,String empName);
}
