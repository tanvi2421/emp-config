package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.dao.EmployeeDao;
import com.entity.Employee;

@Service
public class EmpService {
	@Autowired
	private EmployeeDao employeeDao;
	
	public void addEmployee(Employee employee) {
		
		employeeDao.save(employee);
		
	}
	
	public List<Employee> loadEmp(){
		return (List<Employee>)employeeDao.findAll();
	}
	public List<Employee> loadEmpWithSorting(String input){
		return (List<Employee>)employeeDao.findAll(Sort.by(Sort.Direction.ASC,input));
	}
	
	public boolean searchEmp(int empid) {
		    Optional<Employee> emp=employeeDao.findById(empid);
		    if(emp.isPresent()) {
		    	return true;
		    }
		    return false;
	}
	public void updateEmp(String name,String email) {
		
		employeeDao.updateEmail(email, name);
		
	}

}
