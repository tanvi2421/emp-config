package com.example.boaspringorm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaSpringOrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
