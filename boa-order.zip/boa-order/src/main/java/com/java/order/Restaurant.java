package com.java.order;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.java.order.model.OrderStatus;

@Component
public class Restaurant {

	@RabbitListener(queues = AppConfig.QUEUE)
	public void consumeMessage(OrderStatus status) {
		System.out.println("Message received "+status);
	}
}
