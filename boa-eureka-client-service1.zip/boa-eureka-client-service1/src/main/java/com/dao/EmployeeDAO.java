package com.dao;

import org.springframework.stereotype.Repository;

import com.model.Employee;
import com.model.Employees;

@Repository
public class EmployeeDAO {

	private static Employees list = new Employees();
	
	static {
		list.getEmployeeList().add(new Employee(1, "john","john@mail.com","mumbai"));
		list.getEmployeeList().add(new Employee(2, "steve","steve@mail.com","vegas"));
		list.getEmployeeList().add(new Employee(3, "david","david@mail.com","london"));
	}
	
	public Employees getAll() {
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public void addEmployee(Employee emp) {
		list.addEmployee(emp);
	}

	public Employee findEmployee(String name) {
		for(Employee e:list.getEmployeeList()) {
			if(e.getName().equals(name)) {
				return e;
			}
		}
		return null;
	}
}

