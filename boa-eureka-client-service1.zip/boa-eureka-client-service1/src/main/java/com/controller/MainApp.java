package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.EmployeeDAO;
import com.model.Employee;
import com.model.Employees;

 

@RestController
@RequestMapping("/mainapp")
public class MainApp {
	@Autowired
	private EmployeeDAO dao;
	
	@GetMapping(path = "/empshow",produces = "application/json" )
	public Employees loadEmp() {
		return dao.getAll();
		
	}
	@PostMapping("/adduser")
	public ResponseEntity<Object> addEmp(@RequestBody Employee employee){
		
		int id= dao.getAll().getEmployeeList().size()+1;
		employee.setId(id);
		dao.addEmployee(employee);
		return ResponseEntity.ok("user added");
		}
		
		@GetMapping("/findemp/{name}")
		public Employee findEmp(@PathVariable String name) {

			return dao.findEmployee(name);

		}
		 
}
