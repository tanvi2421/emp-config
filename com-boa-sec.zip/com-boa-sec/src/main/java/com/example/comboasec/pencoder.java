package com.example.comboasec;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class pencoder {

	public static void main(String[] args) {
		BCryptPasswordEncoder en = new BCryptPasswordEncoder();
		
		System.out.println(en.encode("tester123"));
	}

}
