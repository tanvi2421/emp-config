package com.example.comboasec;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainApp {

	@GetMapping("/home")
	public String homePage() {
		return "home";
	}

	@GetMapping("/welcome")
	public String welcomePage() {
		return "welcome";
	}
	

	@GetMapping("/admin")
	public String adminPage() {
		return "admin";
	}
	

	@GetMapping("/emp")
	public String empPage() {
		return "emp";
	}

	@GetMapping("/manager")
	public String mannagerPage() {
		return "manager";
	}
	
	@GetMapping("/tester")
	public String testPage() {
		return "test";
	}
	

	@GetMapping("/common")
	public String commonPage() {
		return "common";
	}

	@GetMapping("/ad")
	public String adPage() {
		return "ad";
	}
}