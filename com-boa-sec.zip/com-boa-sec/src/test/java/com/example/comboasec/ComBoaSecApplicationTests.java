package com.example.comboasec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComBoaSecApplicationTests {

	@Test
	void contextLoads() {
	}

}
